Directory to store P&ID node lists!
