Directory to store P&ID plots!
